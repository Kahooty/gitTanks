# 🎯 gitTanks — Tank Battle Contribution Graph

Git contribution graph activity stylized and containing a retro-style tanks game.

Four tanks spawn in the corners of your contribution grid, using your commit history
as walls and cover, battling it out in a fully automated top-down tank warfare animation.

> Inspired by [pacman-contribution-graph](https://github.com/abozanona/pacman-contribution-graph)
> and [snk](https://github.com/Platane/snk)

---

## 🎮 How It Works

Your GitHub contribution data becomes the battlefield:

| Contribution Level | In-Game Role |
|---|---|
| **NONE** (no contributions) | Open ground — tanks move freely |
| **FIRST_QUARTILE** | Light wall (one shot to destroy) |
| **SECOND_QUARTILE** | Medium wall (one shot to destroy) |
| **THIRD_QUARTILE** | Heavy wall (one shot to destroy) |
| **FOURTH_QUARTILE** | Fortified wall (one shot to destroy) |

All activity blocks are walls. Tanks must shoot to clear a blocked path. One shot destroys any wall.

Four tanks (**Alpha**, **Bravo**, **Charlie**, **Delta**) spawn in the corners
and use AI to navigate, blast through walls, and eliminate each other.
The animation plays until one tank remains victorious.

---

## 🚀 Quick Setup (GitHub Profile)

### 1. Create Your Profile Repository

Create a repo with the **exact same name as your GitHub username**
(e.g., `Kahooty/Kahooty`). This powers your GitHub profile page.

### 2. Add the Workflow

Create `.github/workflows/tank-battle.yml`:

```yaml
name: Generate Tank Battle

on:
  schedule:
    - cron: "0 0 * * *"
  workflow_dispatch:
  push:
    branches:
      - main

jobs:
  generate:
    permissions:
      contents: write
    runs-on: ubuntu-latest
    timeout-minutes: 5

    steps:
      - name: Generate tank-contribution-graph.svg
        uses: Kahooty/gitTanks@main
        with:
          github_user_name: ${{ github.repository_owner }}

      - name: Push to output branch
        uses: crazy-max/ghaction-github-pages@v3.1.0
        with:
          target_branch: output
          build_dir: dist
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

### 3. Add to Your README

Add this to your profile `README.md`:

```html
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/Kahooty/Kahooty/output/tank-contribution-graph-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Kahooty/Kahooty/output/tank-contribution-graph.svg">
  <img alt="tank battle contribution graph" src="https://raw.githubusercontent.com/Kahooty/Kahooty/output/tank-contribution-graph.svg">
</picture>
```

### 4. Trigger It

Push to main, or go to **Actions** → **Generate Tank Battle** → **Run workflow**

---

## 🔫 Tank Personalities

| Tank | Color | Start | Style |
|---|---|---|---|
| **Alpha** | 🟢 Green | Top-left | Aggressive pathfinder |
| **Bravo** | 🔵 Blue | Top-right | Flanking specialist |
| **Charlie** | 🔴 Red | Bottom-left | Wall breaker |
| **Delta** | 🟠 Orange | Bottom-right | Defensive crawler |

---

## 🏆 Scoreboard

The animated scoreboard tracks each tank in real-time:
- **Kill count** increments live as tanks are eliminated
- **💥** appears on a tank's icon the frame it's destroyed
- **🏆** appears on the last tank standing

---

## 🛠️ Local Development

```bash
git clone https://github.com/Kahooty/gitTanks.git
cd gitTanks

# Sample data (no API key needed)
node index.js --sample --username Kahooty

# Real GitHub data
node index.js --username your_github_name --token ghp_your_token

# Different random seed
node index.js --sample --username Kahooty --seed 99
```

Output SVGs are saved to `dist/`.

---

## 📁 Project Structure

```
gitTanks/
├── action.yml                 # GitHub Action definition
├── index.js                   # Main entry point
├── package.json
├── src/
│   ├── fetch-contributions.js # GitHub GraphQL API
│   ├── game-engine.js         # Tank battle simulation
│   ├── svg-renderer.js        # Animated SVG generator
│   └── themes.js              # Light/dark color themes
├── .github/workflows/
│   └── main.yml               # Example workflow
└── README.md
```

---

## 📜 License

MIT

---

_generated with [Kahooty/gitTanks](https://github.com/Kahooty/gitTanks)_
